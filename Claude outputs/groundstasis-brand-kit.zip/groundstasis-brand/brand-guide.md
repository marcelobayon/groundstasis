# Ground Stasis — Brand Guide

_Version 1.0 · Satellite monitoring for construction lenders · groundstasis.com_

This guide exists so Ground Stasis looks and sounds the same everywhere — the site, Crunchbase, LinkedIn, email, a pitch deck. Consistency is what makes a one-person company read as trustworthy. Reuse this file; don't reinvent it.

---

## 1. What the brand stands for

Ground Stasis tells a construction lender **the moment a financed site goes quiet** — an independent satellite signal that fills the blind spot between inspections.

Four principles govern every decision, visual or verbal:

1. **Evidence-led.** We show what the satellite observed and the dates it observed it. We never assert more than the data supports.
2. **Honest about limits.** We say what satellite data *cannot* do, out loud. This candor is the product, not a disclaimer.
3. **Calm and professional.** The audience is lenders moving real money. The brand is quiet, precise, and unhyped — closer to an instrument panel than a billboard.
4. **Decisions, not technology.** We lead with the lender's question ("is it still moving?"), not with spectral indices or orbital mechanics.

---

## 2. The trust moat (voice & candor rules)

A logo doesn't build trust with lenders — **candor does.** These are hard rules, not suggestions. They are the single biggest differentiator against both hype-y startups and opaque enterprise tools.

**Always**

- Call it a **"monitoring signal,"** never "proof," "verification," or "guarantee."
- Keep **reported vs. observed** strictly separate ("you reported X; the satellite observed Y").
- Treat **no usable imagery as a DATA GAP**, never as "no activity."
- Lead with the decision and the dollar stakes; keep the tech in a footnote.
- Prefer **specifics** — numbers, dates, observation counts — over adjectives.

**Never**

- Claim a project has **stopped, been abandoned, or involves fraud.**
- Imply the satellite verifies **work quality, completed value, code compliance, or draw eligibility.**
- Invent **testimonials, customer counts, accuracy percentages, or savings stats.** If we don't have a real number, we don't publish one.
- Use countdown timers, false urgency, or "limited spots." Lenders read that as a scam.

**Voice in one line:** a sharp, straight-talking analyst who respects the reader's intelligence and never oversells.

| Don't write | Write instead |
|---|---|
| "We detected the project has stopped." | "Observed activity has gone unusually quiet — worth a closer look." |
| "99% accurate stall detection." | "Flags unusual drops in observable change, with a confidence rating on every signal." |
| "Trusted by top lenders." | "Built for small and private construction lenders." |
| "Guaranteed to protect your loan." | "An independent signal to help you decide when a site deserves another look." |

---

## 3. Logo

### 3.1 The mark

A single **observation point** (orange node on an upright) standing over a **receding ground plane** (three lines). It reads as *ground + a fixed point of continuous observation* — deliberately **not** a satellite, dish, or globe. That restraint is the point: the brand watches the ground, calmly.

### 3.2 Variants & when to use them

| Variant | File | Use on |
|---|---|---|
| Light logo (lockup) | `logo/gs-logo-horizontal-dark-bg.svg/.png` | Dark / navy backgrounds |
| Dark logo (lockup) | `logo/gs-logo-horizontal-light-bg.svg/.png` | White / light backgrounds |
| Mark only — light | `logo/gs-mark-dark-bg.svg/-512.png` | Dark backgrounds, tight spaces |
| Mark only — dark | `logo/gs-mark-light-bg.svg/-512.png` | Light backgrounds, tight spaces |
| App icon / avatar (navy) | `social/gs-icon-navy-512/400/250.png` | Profile photos, app icons, directories |

Prefer SVG wherever the surface accepts it (it stays crisp at any size); use PNG for raster-only placements.

### 3.3 Rules

- **Clear space:** keep empty space equal to the node's diameter on all sides of the lockup. Nothing crowds the logo.
- **Minimum size:** mark no smaller than **24 px**; full lockup no smaller than **120 px** wide.
- **The node is always orange (#FF6B00).** It is the one fixed point of the brand — never recolor it.
- **Contrast:** light logo only on dark; dark logo only on light. Never place a logo where the ground lines disappear.

### 3.4 Misuse (don't)

Don't stretch or squash it · don't rotate it · don't add shadows, gradients, bevels, or glows · don't recolor the node · don't rebuild or re-space the ground lines · don't put the mark inside another shape or badge · don't place the light logo on a light photo.

---

## 4. Color

Navy and white carry the brand; **orange is used sparingly, as the single accent** — the one place the eye should land (the node, the primary button). Overusing orange kills its signal value.

### 4.1 Core palette

| Role | Name | Hex |
|---|---|---|
| Primary / ink / dark bg | Navy | `#0A192F` |
| Elevated navy (cards on dark) | Navy 700 | `#122A4A` |
| **Accent / action** | **Orange** | **`#FF6B00`** |
| Accent hover | Orange 700 | `#E25F00` |
| Text / muted | Slate | `#64748B` |
| Lines / faint (logo ground) | Slate 400 | `#94A3B8` |
| Hairlines / borders | Slate 200 | `#E2E8F0` |
| Light surface | Slate 50 | `#F8FAFC` |
| Page / reversed text | White | `#FFFFFF` |

### 4.2 Status color system (functional — keep consistent with the product)

The product's five states each own a color. Use these the same way everywhere, including charts and the results page.

| Status | Meaning | Hex |
|---|---|---|
| ACTIVE | Observed activity in line with baseline | Teal `#00BFA5` |
| WATCH | Easing, worth watching | Amber `#F59E0B` |
| REVIEW | Below baseline, deserves a look | Review orange `#FB8C00` |
| STASIS | Unusually quiet | Red `#EF4444` |
| DATA GAP | Not enough usable imagery | Slate `#64748B` |

**Accessibility:** navy-on-white and white-on-navy both pass WCAG AA for body text. Orange `#FF6B00` is an accent — don't use it for small body text on white (contrast is borderline); use it for buttons, the node, and large emphasis only.

---

## 5. Typography

**Brand typeface: Inter** (Google Fonts, free, open-license). Geometric-humanist, highly legible, and reads as modern-professional without being trendy.

- **Fallback stack:** `Inter, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif` (the site already uses this stack).
- **Weights:** 400 (body), 600 (UI / emphasis), 700 (headings, wordmark), 800 (hero only).
- **Letter-spacing:** tighten headings slightly (`-0.02em`); leave body at default.

### Type scale (web)

| Use | Size / weight |
|---|---|
| Hero (H1) | 44–54 px / 800 |
| Section (H2) | 30 px / 700 |
| Subhead (H3) | 18–20 px / 700 |
| Body | 16–17 px / 400 |
| Small / caption | 13 px / 400–500 |
| Eyebrow / kicker | 12–13 px / 700, uppercase, `+0.12em` |

The wordmark "Ground Stasis" is set in Inter 700, `-0.02em`. Don't substitute another font for the wordmark.

---

## 6. Imagery & iconography

- **Imagery:** restrained and real — satellite/aerial context, construction sites, clean data views. No stock-photo handshakes, no hard-hat clichés, no faux dashboards with invented numbers.
- **Icons:** thin-to-medium line icons, rounded caps, matching the mark's stroke feel. One accent color max per view.
- **Charts:** flat, no gradients or 3D; one measure per chart; status colors as above; always label units and dates.

---

## 7. Asset index (what's in this kit)

```
groundstasis-brand/
  brand-guide.md                          ← this file
  logo/
    gs-logo-horizontal-dark-bg.svg/.png   full lockup, light logo (dark bg)
    gs-logo-horizontal-light-bg.svg/.png  full lockup, dark logo (light bg)
    gs-mark-dark-bg.svg / -512.png        mark only, for dark bg
    gs-mark-light-bg.svg / -512.png       mark only, for light bg
  social/
    gs-icon-navy-512/400/250.png          square avatar / app icon (LinkedIn, Crunchbase, X, directories)
    gs-icon-white-512.png                 square avatar, light variant
    gs-icon-navy.svg                       vector square icon
    og-image-1200x630.png                 link-preview / share card
    linkedin-banner-1128x191.png          LinkedIn page/profile banner
  favicon/
    favicon.svg                            modern SVG favicon
    favicon.ico                            16/32/48 multi-res (classic)
    favicon-16/32/48.png                   individual sizes
    apple-touch-icon-180.png               iOS home-screen icon
  video/
    groundstasis-intro.mp4                 8-second animated logo intro (with original audio)
```

### Where to use which
- **Profile photo** (LinkedIn, Crunchbase, X, G2, any directory): `gs-icon-navy-250.png` (or 400/512 if they want larger).
- **Website header:** the horizontal lockup, matched to the background.
- **Browser tab:** `favicon.ico` + `favicon.svg` + `apple-touch-icon-180.png` in the site root.
- **Link previews / social shares:** `og-image-1200x630.png`.
- **LinkedIn banner:** `linkedin-banner-1128x191.png`.

---

## 8. Quick do / don't

**Do:** keep orange rare and intentional · let navy and whitespace carry the page · state limits plainly · use real numbers or none · keep the wordmark in Inter 700.

**Don't:** recolor the node · stack multiple accent colors · invent proof or social proof · use urgency gimmicks · stretch or decorate the logo · describe the product as anything more than a monitoring signal.
